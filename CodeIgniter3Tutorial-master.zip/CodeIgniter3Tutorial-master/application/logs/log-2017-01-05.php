<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-01-05 00:07:27 --> Severity: error --> Exception: syntax error, unexpected '}' E:\XAMPP\htdocs\CodeIgniter3Tutorial\application\controllers\Welcome.php 25
ERROR - 2017-01-05 00:08:04 --> Severity: error --> Exception: syntax error, unexpected 'extend' (T_STRING), expecting '{' E:\XAMPP\htdocs\CodeIgniter3Tutorial\application\controllers\Welcome.php 4
